 <? 
Header("Location: ../index.php"); 
exit(); 
?> 