#!/bin/bash
pfad="/var/www/"
datei=$pfad"files/linux/bitratecontrol.sh"
while [ true ] ; do
$datei
sleep 120
done