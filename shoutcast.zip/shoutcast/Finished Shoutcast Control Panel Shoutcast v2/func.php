<?php
phpinfo ();
?>