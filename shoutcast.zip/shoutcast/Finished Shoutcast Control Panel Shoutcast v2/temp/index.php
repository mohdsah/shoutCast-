<?PhP
Header('Location: ../index.php'); 
?> 
